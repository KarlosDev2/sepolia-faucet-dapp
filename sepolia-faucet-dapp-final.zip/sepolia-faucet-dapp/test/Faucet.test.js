const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Faucet", function () {
  let faucet, owner, addr1;

  beforeEach(async function () {
    [owner, addr1] = await ethers.getSigners();
    const Faucet = await ethers.getContractFactory("Faucet");
    faucet = await Faucet.deploy();
    await faucet.deployed();
  });

  it("Should set the right owner", async function () {
    expect(await faucet.owner()).to.equal(owner.address);
  });

  it("Should allow funding and withdrawals", async function () {
    await owner.sendTransaction({ to: faucet.address, value: ethers.utils.parseEther("1") });
    expect(await ethers.provider.getBalance(faucet.address)).to.equal(ethers.utils.parseEther("1"));

    await faucet.connect(addr1).requestTokens();
    const bal = await ethers.provider.getBalance(addr1.address);
    expect(bal).to.be.ok;
  });
});
